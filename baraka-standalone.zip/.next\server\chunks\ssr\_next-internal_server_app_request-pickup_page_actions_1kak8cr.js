module.exports=[45481,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_request-pickup_page_actions_1kak8cr.js.map